import { HashRouter, Routes, Route } from "react-router-dom";

import Userheader from "./userheader";
import Myregister from "./register";
import Mylogin from "./login";

import Topbar from "../scenes/global/Topbar";

const UserModule = ({ loggedIn,setLoggedIn}) => {
  return (
    <>
      <Topbar />

      <Routes>
        <Route exact path="/" element={<Mylogin   loggedIn={loggedIn} setLoggedIn={setLoggedIn}/>} />
        <Route exact path="*" element={<Mylogin />} />
        <Route exact path="/register" element={<Myregister />} />
      </Routes>
    </>
  );
};

export default UserModule;
