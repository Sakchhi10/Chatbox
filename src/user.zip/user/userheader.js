import { Link } from "react-router-dom";

const Userheader=()=>{

    return(

        <div className="container mt-3 mb-5">
            <div className="row">
               
                <div className="col-lg-12 text-center">

                    <div className="btn-group">
                       
                        <Link className="btn btn-success" to="/register"><i className="fa fa-user-plus"></i> Create Account</Link>
                        <Link className="btn btn-warning text-white" to="/"><i className="fa fa-lock"></i> Login</Link>
                    </div>

                </div>

            </div>
        </div>

       
    )
}

export default Userheader;