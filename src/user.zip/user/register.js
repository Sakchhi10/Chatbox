import { useState } from "react";
import swal from "sweetalert";
import axios from "axios";
import { Link } from "react-router-dom";

const Myregister = () => {
    const [fullname, setFullname] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [repassword, setRepassword] = useState("");
  const [matchMessage, setMatchMessage] = useState("");

  const save = async () => {
    if (password === repassword) {
      const url = "https://apimlm.bloomitsolutions.in/auth/register";
      const userInfo = {
        username: fullname,
        mobile: mobile,
        email: email,
        password: password,
        
      };

      try {
        const response = await axios.post(url, userInfo);
        const userData = response.data;
        console.log("userData",userData);

        swal(`Seller, ${fullname}`, "Account Created Successfully", "success");

        // Reset form fields and match message
        setFullname("");
        setMobile("");
        setPassword("");
        setEmail("");
        setRepassword("");
        setMatchMessage("");
      } catch (error) {
        console.error("Error:", error);
        swal("Error", "Failed to create account. Please try again later.", "error");
      }
    } else {
      // Passwords do not match, show a message
      setMatchMessage("Passwords do not match");
    }
  };

  return (
    <div className="container-fluid mt-4">
      <div className="row">
        <div className="col-lg-4"></div>
        <div className="col-lg-4">
          <div className="card border-0 shadow-lg">
            <div className="card-header bg-primary text-center text-white">
              Create New Account
            </div>
            <div className="card-body">
              <div className="mb-3">
                <label>Name</label>
                <input
                  type="text"
                  className="form-control"
                  onChange={(obj) => setFullname(obj.target.value)}
                  value={fullname}
                />
              </div>

              <div className="mb-3">
                <label>Mobile No</label>
                <input
                  type="number"
                  className="form-control"
                  onChange={(obj) => setMobile(obj.target.value)}
                  value={mobile}
                />
              </div>

              <div className="mb-3">
                <label>EMail Id</label>
                <input
                  type="email"
                  className="form-control"
                  onChange={(obj) => setEmail(obj.target.value)}
                  value={email}
                />
              </div>

              <div className="mb-3">
                <label>Password</label>
                <input
                  type="password"
                  className="form-control"
                  onChange={(obj) => setPassword(obj.target.value)}
                  value={password}
                />

              </div>

              <div className="mb-3">
                <label>Re-enter Password</label>
                <input
                  type="password"
                  className="form-control"
                  onChange={(obj) => setRepassword(obj.target.value)}
                  value={repassword}
                /> 

                
                
               </div>

              <p className="text-danger">{matchMessage}</p>
            </div>
            {/* card body end */}
            <div className="card-footer text-center">
              <button className="btn btn-danger" onClick={save}>
                Register
              </button>

              <p>Already a User?</p>
              <Link to="/">Login</Link>
            </div>
          </div>
        </div>

        <div className="col-lg-4"></div>
      </div>
    </div>
  );
};

export default Myregister;
