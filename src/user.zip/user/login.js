import { useState,useEffect } from "react";
import { Link } from "react-router-dom";
import swal from "sweetalert";
import axios from "axios";
import {useNavigate} from "react-router-dom"

const Mylogin=({ setLoggedIn})=>{

    const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate(); 
  
  

  const login = async () => {
    if (email === "" || password === "") {
      swal("Error", "Empty Email or Password", "warning");
    } else {
      const url = `https://apimlm.bloomitsolutions.in/auth/login`;

      try {
        const response = await axios.post(url, {
          email: email,
          password: password,
        });
        swal("success","login successfully","success")

        setLoggedIn(true)
        const userinfo = response.data;

        console.log("userinfo:", userinfo);

        // if (userinfo && userinfo.length > 0) {
        //   localStorage.setItem("sellerid", userinfo[0].id);
        //   localStorage.setItem("sellername", userinfo[0].name);
        //   window.location.reload(); // Reload the page after successful login
        // } else {
        //   swal("Fail", "Invalid or not exists", "error");
        // }
      } catch (error) {
        console.error("Error:", error);
        // Handle network errors
        swal("Error", "Failed to log in. Please try again later.", "error");
      }
    }
  };

    return(

        <div className="container-fluid mt-4">
            <div className="row">
                <div className="col-lg-4"></div>
                <div className="col-lg-4">
                    
                    <div className="card border-0 shadow-lg">

                        <div className="card-header bg-primary text-center text-white"> Login</div> {/*   card header end */}

                        <div className="card-body">

                            <div className="mb-3">
                                <label> EMail Id</label>
                                <input type="email" className="form-control"
                                onChange={obj=>setEmail(obj.target.value)} value={email}/>
                            </div> 

                            <div className="mb-3">
                                <label> Password</label>
                                <input type="password" className="form-control"
                                onChange={obj=>setPassword(obj.target.value)} value={password}/>
                            </div>  

                        </div>   {/*card body end*/} 

                        <div className="card-footer text-center">

                            <button className="btn btn-danger" onClick={login}>Login</button>

                            <p>Don't have an account yet?</p>
                            <Link to="/register">Create an account</Link>

                        </div> {/*   card footer end */}

                    </div>
                </div>

                <div className="col-lg-4"></div>

            </div>

        </div>
    )

}

export default Mylogin;